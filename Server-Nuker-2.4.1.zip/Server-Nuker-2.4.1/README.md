# Server Nuker
### Description
* **Author:** Tech Vevo
* **Current Version:** 2.3.1
* This bot & source is made for fun and purely EDUCATIONAL PURPOSE! I do not take any responsibilty or liability due to the damage/problems caused by this product. It is your (the user's) sole responsibilty.
* Find the latest Changelog [here](https://github.com/TechVevo/Server-Nuker/blob/master/Changelog.md).

------------------------------------------
### USAGE
#### GET THE LATEST VERSION [HERE](https://github.com/TechVevo/Server-Nuker/releases/tag/v2.3.0)!
#### YOU NEED TO HAVE PRIVILEGED GATEWAY INTENTS > SERVER MEMBERS INTENT TURNED ON FOR KICK ALL & BAN ALL TO WORK!
![](https://i.imgur.com/aWlEXab.png)

#### 1. EXE Method
- The easiest way to use this bot is to go the [releases tab](https://github.com/TechVevo/Server-Nuker/releases) and downloading the latest EXE.
  - > I know many people might be very doubtful. If you do not trust the EXE run a virus scan on it or put it in https://virustotal.com
  - Download the EXE and place it in a seperate folder (Name it whatever you want).
  - Now open notepad and enter your bot's token and prefix like this:
    ```
    TOKEN=<your bot's token>
    PREFIX=<your prefix>
    ```
  - Now press `Ctrl+S` (or) give `Save As` and navigate to the folder where you put the EXE.
  - Change the save as type from "Text Document (.txt)" to "All Files".
  - Now for the name, enter `.env` and save it.
  - Open the EXE and enjoy nuking!

#### 2. MANUAL Method
> **Note:** If you are going to follow this method, basic knowledge of coding is required. If you are new/don't want the hassle, then I highly suggest you to follow the above given [EXE Method](https://github.com/TechVevo/Server-Nuker#1-exe-method)!
- If you do not trust the EXE (or) if you want to run directly from the source, follow the instructions below. You also need to **satisfy the "[REQUIREMENTS](https://github.com/TechVevo/Server-Nuker#requirements)" given below!** (You do not need those for the EXE)
  - Go to the master branch and click on "Code" and give "Download as ZIP".
![](https://i.imgur.com/uPRwVUa.png)
  - Extract it and navigate inside the folder. It should look somewhat like this:
![](https://i.imgur.com/ZtSBeiD.png)
  - Open the .env file in NotePad and edit the TOKEN with your bot's token. You can also change the prefix (Default is `.`) if you want.
  - Now open a terminal here or navigate to this folder in cmd.
  - Type in `npm i`. Doing so will install all the necessary dependancies
  - Now type in `node index.js` or `npm start`
  - Once you get the "ready" message that looks something like "<Your Bot> is ready!", you can run `<prefix>help` to get a list of commands.

------------------------------------------
### REQUIREMENTS
  **NOTE:** None of these are required if you are running the compiled EXE which can be found in the releases or [here](https://github.com/TechVevo/Server-Nuker/releases).
  
\- Node JS and Python have been linked below:
- [Node JS v16](https://nodejs.org/en/)
- [Python3](https://www.python.org/downloads/)
- NPM (It is installed by default if you install Node JS)
- Basic coding knowledge in JavaScript (You can watch some tutorials online)

------------------------------------------
### LICENSING
\- This product is licensed under the [GNU General Public License v3.0](https://github.com/TechVevo/Server-Nuker/blob/master/LICENSE).

------------------------------------------
### ©️COPYRIGHT DISCLAIMER
- I am not encouraging raiding or any other similar form. It is purely for educational purposes only. To companies including but not limited to Discord this is a :copyright:copyright disclaimer Under Section 107 of the Copyright Act 1976 where allowance is made for "fair use" for purposes such as criticism, comment, news reporting, teaching, scholarship, and research. Fair use is a use permitted by copyright statute that might otherwise be infringing. Non-profit, educational or personal use tips the balance in favor of fair use.
- If for any reason this needs to be removed, please contact me at tech.vevo15@gmail.com
